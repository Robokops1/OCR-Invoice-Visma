import ultralytics
ultralytics.checks()